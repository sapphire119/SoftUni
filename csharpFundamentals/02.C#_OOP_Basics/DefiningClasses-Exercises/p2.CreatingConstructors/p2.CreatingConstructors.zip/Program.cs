﻿using System;

public class Program
{
    public static void Main()
    {
        var person = new Person();
        var person2 = new Person(23);
        var person3 = new Person("Pesho", 12);
    }
}

