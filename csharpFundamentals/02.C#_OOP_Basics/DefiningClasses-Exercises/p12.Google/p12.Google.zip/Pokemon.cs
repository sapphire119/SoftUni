﻿public class Pokemon
{
    private string name;
    private string type;

    public Pokemon() { }

    public Pokemon(string name, string type)
        : this()
    {
        this.Name = name;
        this.Type = type;
    }

    public string Type
    {
        get
        {
            return this.type;
        }
        set
        {
            this.type = value;
        }
    }

    public string Name
    {
        get
        {
            return this.name;
        }
        set
        {
            this.name = value;
        }
    }

    public override string ToString()
    {
        return $"{this.Name} {this.Type}";
    }
}
