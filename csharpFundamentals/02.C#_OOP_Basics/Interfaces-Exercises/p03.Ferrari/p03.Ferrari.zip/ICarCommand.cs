﻿public interface ICarCommand
{
    string UseBrakes();

    string PushGasPedal();
}