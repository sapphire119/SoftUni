﻿public interface IBuyer
{
    void BuyFood();

    long BoughtFood { get; }
}
