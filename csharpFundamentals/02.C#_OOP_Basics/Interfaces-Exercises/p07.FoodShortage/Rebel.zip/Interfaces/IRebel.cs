﻿public interface IRebel : IBuyer, IPerson
{
    string Group { get; }
}
