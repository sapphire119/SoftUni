﻿namespace p05.StackOfStrings
{
    using System;

    public class StartUp
    {
        public static void Main()
        {

        }
    }
}
