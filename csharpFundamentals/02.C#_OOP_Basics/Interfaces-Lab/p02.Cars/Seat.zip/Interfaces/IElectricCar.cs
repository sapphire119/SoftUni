﻿public interface IElectricCar
{
    int Battery();
}