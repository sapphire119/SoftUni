﻿public interface ICar
{
    string Model();

    string Color();

    string Start();

    string Stop();
}