﻿using System.Collections.Generic;

public class FlourtypeType
{
    public static Dictionary<string, decimal> FlourTypes = new Dictionary<string, decimal>()
    {
        { "white", 1.5M },
        { "wholegrain", 1.0M }
    };
}