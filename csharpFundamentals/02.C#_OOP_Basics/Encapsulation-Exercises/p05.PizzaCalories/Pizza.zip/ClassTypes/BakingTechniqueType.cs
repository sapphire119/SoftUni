﻿using System.Collections.Generic;

public class BakingTechniqueType
{
    public static Dictionary<string, decimal> bakingTechnique = new Dictionary<string, decimal>()
    {
        { "crispy", 0.9M  },
        { "chewy", 1.1M },
        { "homemade", 1.0M }
    };
}
