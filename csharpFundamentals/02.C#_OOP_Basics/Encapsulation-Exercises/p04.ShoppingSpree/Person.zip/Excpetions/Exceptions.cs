﻿using System;

public class Exceptions
{
    public static ArgumentException nameException = new ArgumentException("Name cannot be empty");
    public static ArgumentException moneyException = new ArgumentException("Money cannot be negative");
}