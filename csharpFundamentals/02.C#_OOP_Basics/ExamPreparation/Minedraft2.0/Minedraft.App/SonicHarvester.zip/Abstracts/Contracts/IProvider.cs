﻿public interface IProvider : IUnit
{
    double EnergyOutput { get; }
}