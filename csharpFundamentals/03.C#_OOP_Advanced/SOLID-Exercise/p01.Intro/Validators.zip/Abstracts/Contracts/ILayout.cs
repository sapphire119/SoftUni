﻿public interface ILayout
{
    string Format(string[] arguments);
}