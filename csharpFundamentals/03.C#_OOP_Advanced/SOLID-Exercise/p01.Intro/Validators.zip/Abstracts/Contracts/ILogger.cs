﻿public interface ILogger
{
    void Log(string date, string reportLevel, string message);
}