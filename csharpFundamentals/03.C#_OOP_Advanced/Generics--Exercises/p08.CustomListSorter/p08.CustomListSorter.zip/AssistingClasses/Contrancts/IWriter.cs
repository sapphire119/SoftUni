﻿public interface IWriter
{
    void WriteLine<T>(T item);
}