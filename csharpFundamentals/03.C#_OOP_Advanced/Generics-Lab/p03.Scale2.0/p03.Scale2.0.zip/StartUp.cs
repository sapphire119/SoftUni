﻿namespace p03.Scale2._0
{
    using System;

    public class StartUp
    {
        public static void Main()
        {
            var scale = new Scale<string>("Pesho", "Pesho");
            Console.WriteLine(scale.GetHeavier());
        }
    }
}
