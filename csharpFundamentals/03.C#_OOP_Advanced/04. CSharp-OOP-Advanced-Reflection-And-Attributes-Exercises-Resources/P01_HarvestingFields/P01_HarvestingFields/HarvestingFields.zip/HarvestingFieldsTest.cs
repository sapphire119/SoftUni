﻿ namespace P01_HarvestingFields
{
    using System;

    public class HarvestingFieldsTest
    {
        public static void Main()
        {
            Engine engine = new Engine();
            engine.Run();
        }
    }
}
