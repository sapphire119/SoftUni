﻿public interface IWriter
{
    void WriteLine<T>(T element);
}