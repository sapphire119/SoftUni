﻿namespace P02_BlackBoxInteger
{
    using System;

    public class BlackBoxIntegerTests
    {
        public static void Main()
        {
            Engine engine = new Engine();
            engine.Run();
        }
    }
}
