﻿public interface IReadable
{
    string ReadLine();
}