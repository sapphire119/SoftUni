﻿public interface IWriteable
{
    void WriteLine<T>(T element);
}