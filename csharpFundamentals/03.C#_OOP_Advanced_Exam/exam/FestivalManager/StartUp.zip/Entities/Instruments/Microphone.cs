﻿namespace FestivalManager.Entities.Instruments
{
    public class Microphone : Instrument
    {
        public override int RepairAmount => 80;
    }
}
