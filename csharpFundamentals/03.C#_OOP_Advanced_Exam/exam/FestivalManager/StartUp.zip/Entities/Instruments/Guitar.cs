﻿namespace FestivalManager.Entities.Instruments
{
    public class Guitar : Instrument
    {
        public override int RepairAmount => 60;
    }
}
