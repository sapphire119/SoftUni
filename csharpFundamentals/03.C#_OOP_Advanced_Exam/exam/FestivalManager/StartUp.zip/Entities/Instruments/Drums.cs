﻿namespace FestivalManager.Entities.Instruments
{
    public class Drums : Instrument
    {
        public override int RepairAmount => 20;
    }
}
