﻿namespace P01_StudentSystem.Data.Models
{
    public enum ResourceType
    {
        //enum – can be Video, Presentation, Document or Other
        Video,
        Presentation,
        Document,
        Other
    }
}