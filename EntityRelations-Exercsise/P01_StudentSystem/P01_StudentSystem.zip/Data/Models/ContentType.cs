﻿namespace P01_StudentSystem.Data.Models
{
    public enum ContentType
    {
        //enum – can be Application, Pdf or Zip)
        Application,
        Pdf,
        Zip
    }
}
