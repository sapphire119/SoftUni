﻿namespace P01_StudentSystem.Data
{
    public static class Configuration
    {
        public const string ConfigurationString = @"Server=DESKTOP-03A7982\SQLEXPRESS;Database=StudentSystem;Integrated Security=True";
    }
}
