﻿namespace P01_HospitalDatabase.Data
{
    public class Configuration
    {
        public const string ConnectionString = @"Server=DESKTOP-03A7982\SQLEXPRESS;Database=Hospital;Integrated Security=True";
    }
}
