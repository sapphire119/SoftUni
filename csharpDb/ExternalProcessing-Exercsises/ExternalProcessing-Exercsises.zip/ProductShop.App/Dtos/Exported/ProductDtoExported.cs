﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ProductShop.App.Dtos.Exported
{
    public class ProductDtoExported
    {
        public string Name { get; set; }

        public decimal Price { get; set; }

        public string Seller { get; set; }
    }
}
