﻿namespace BookShop.Data
{
    public static class Configuration
    {
        public const string ConfigurationString = @"Server=DESKTOP-03A7982\SQLEXPRESS;Database=BookShop;Integrated Security=True";
    }
}
