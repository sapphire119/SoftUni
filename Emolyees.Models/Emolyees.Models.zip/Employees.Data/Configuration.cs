﻿namespace Employees.Data
{
    public static class Configuration
    {
        public const string ConfigurationString = @"Server=.\SQLEXPRESS;Database=Employees;Integrated Security=True";
    }
}
