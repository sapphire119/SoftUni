﻿namespace Employees.App.ModelsDto
{
    public class EmployeeManagerIdDto
    {
        public int? ManagerId { get; set; }
    }
}
