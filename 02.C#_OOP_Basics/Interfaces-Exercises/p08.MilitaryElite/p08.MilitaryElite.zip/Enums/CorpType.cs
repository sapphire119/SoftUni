﻿public enum CorpType
{
    Airforces,
    Marines
}