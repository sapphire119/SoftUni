﻿public enum MissionType
{
    inProgress,
    Finished
}