﻿public interface ISpy : ISoldier
{
    long CodeNumber { get; }
}