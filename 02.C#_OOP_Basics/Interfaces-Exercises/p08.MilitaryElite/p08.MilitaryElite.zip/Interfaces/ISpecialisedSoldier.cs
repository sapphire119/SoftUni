﻿public interface ISpecialisedSoldier : IPrivate
{
    CorpType Corp { get; }
}