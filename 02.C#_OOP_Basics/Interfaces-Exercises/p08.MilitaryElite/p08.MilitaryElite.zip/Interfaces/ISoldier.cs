﻿public interface ISoldier
{
    int Id { get; }

    string FirstName { get; }

    string LastName { get; }
}