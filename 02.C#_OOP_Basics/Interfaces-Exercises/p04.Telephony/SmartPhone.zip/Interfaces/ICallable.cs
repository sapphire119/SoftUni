﻿public interface ICallable
{
    string CallOtherPhones();
}