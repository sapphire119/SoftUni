﻿public interface IBrowseable
{
    string BrowseInternet();
}