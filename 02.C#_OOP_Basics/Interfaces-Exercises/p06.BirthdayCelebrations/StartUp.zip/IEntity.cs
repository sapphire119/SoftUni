﻿public interface IEntity
{
    string BirthDate { get; }
}