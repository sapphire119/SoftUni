﻿public interface IFeline : IMammal
{
    string Breed { get; }
}