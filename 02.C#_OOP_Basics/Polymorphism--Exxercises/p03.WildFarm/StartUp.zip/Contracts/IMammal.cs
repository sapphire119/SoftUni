﻿public interface IMammal : IAnimal
{
    string LivingRegion { get; }
}