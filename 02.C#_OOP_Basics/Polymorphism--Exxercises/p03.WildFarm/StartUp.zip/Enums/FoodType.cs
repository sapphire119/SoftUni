﻿public enum FoodType
{
    Vegetable,
    Fruit,
    Meat,
    Seeds
}