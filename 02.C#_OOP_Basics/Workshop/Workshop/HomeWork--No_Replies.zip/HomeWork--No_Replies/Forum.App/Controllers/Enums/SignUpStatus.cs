﻿public enum SignUpStatus
{
    Success,
    DetailsError,
    UsernameTakenError
}