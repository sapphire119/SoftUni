﻿using System;
using System.Collections.Generic;

public class RandomList : List<string>
{
    public string RandomString()
    {
        var random = new Random();
        var randomIndex = random.Next(0, base.Count);

        var elementToRemove = base[randomIndex];
        base.RemoveAt(randomIndex);

        return elementToRemove;
    }
}