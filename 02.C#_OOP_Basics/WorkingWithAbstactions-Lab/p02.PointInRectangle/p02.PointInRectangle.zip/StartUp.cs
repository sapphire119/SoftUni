﻿namespace p02.PointInRectangle
{
    using System;
    using System.Linq;

    public class StartUp
    {
        public static void Main()
        {
            var coordinates = Console.ReadLine().Split().Select(decimal.Parse).ToArray();

            var topLeftPointOfRectangle = new Point(coordinates[0], coordinates[1]);
            var bottomRightPointOfRectangle = new Point(coordinates[2], coordinates[3]);

            var rectangle = new Rectangle(topLeftPointOfRectangle, bottomRightPointOfRectangle);

            var lines = int.Parse(Console.ReadLine());

            for (int count = 0; count < lines; count++)
            {
                var currentPoint = Console.ReadLine().Split().Select(decimal.Parse).ToArray();
                Console.WriteLine(rectangle.Contains(new Point(currentPoint[0], currentPoint[1])));
            }
        }
    }
}
