﻿public class Point
{
    private decimal x;
    private decimal y;

    public Point() { }

    public Point(decimal x, decimal y)
        : this()
    {
        this.X = x;
        this.Y = y;
    }

    public decimal Y
    {
        get
        {
            return this.y;
        }
        set
        {
            this.y = value;
        }
    }

    public decimal X
    {
        get
        {
            return this.x;
        }
        set
        {
            this.x = value;
        }
    }

}